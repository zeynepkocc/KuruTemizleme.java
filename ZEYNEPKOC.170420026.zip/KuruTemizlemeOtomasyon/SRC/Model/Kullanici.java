package Model;

public class Kullanici {
	private String Ad;
	private String Soyad;
	private String KullaniciAdi;
	private String Sifre;
	private String type;
	
	public Kullanici(String ad, String soyad, String kullaniciAdi, String sifre, String type) {
		super();
		Ad = ad;
		Soyad = soyad;
		KullaniciAdi = kullaniciAdi;
		Sifre = sifre;
		this.type = type;
	}
	public Kullanici() {}
	
	
	public String getAd() {
		return Ad;
	}
	public void setAd(String ad) {
		Ad = ad;
	}
	public String getSoyad() {
		return Soyad;
	}
	public void setSoyad(String soyad) {
		Soyad = soyad;
	}
	public String getKullaniciAdi() {
		return KullaniciAdi;
	}
	public void setKullaniciAdi(String kullaniciAdi) {
		KullaniciAdi = kullaniciAdi;
	}
	public String getSifre() {
		return Sifre;
	}
	public void setSifre(String sifre) {
		Sifre = sifre;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}


	
}
