package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import DBHelper.DbConnection;

public class AdminPer extends Admin{
	private DbConnection conn=new DbConnection();
	private String kullaniciadi;
	private String ucret;
	private String teslimsaat;
	private String gteslimsaat;
	Connection con=conn.connDb();
	
	public String getUcret() {
		return ucret;
	}

	public void setUcret(String ucret) {
		this.ucret = ucret;
	}
	public String getKullaniciadi() {
		return kullaniciadi;
	}

	public void setKullaniciadi(String kullaniciadi) {
		this.kullaniciadi = kullaniciadi;
	}

	public String getTeslimsaat() {
		return teslimsaat;
	}

	public void setTeslimsaat(String teslimsaat) {
		this.teslimsaat = teslimsaat;
	}

	public String getGteslimsaat() {
		return gteslimsaat;
	}

	public void setGteslimsaat(String gteslimsaat) {
		this.gteslimsaat = gteslimsaat;
	}
	Statement st=null;
	ResultSet rs=null;
	PreparedStatement preparedStatement=null;
	
	public AdminPer() {}

	public AdminPer(String ad, String soyad, String kullaniciAdi, String sifre, String type) {
		super(ad, soyad, kullaniciAdi, sifre, type);
	}
	public AdminPer(String kullaniciadi, String ucret, String teslimsaat, String gteslimsaat) {
		this.kullaniciadi=kullaniciadi;
		this.ucret=ucret;
		this.teslimsaat=teslimsaat;
		this.gteslimsaat=gteslimsaat;
	}
	public ArrayList<Kullanici> getPersonelList() throws SQLException{
		ArrayList<Kullanici> list=new ArrayList<>();
		Kullanici obj;
		try {
			st=con.createStatement();
			rs=st.executeQuery("SELECT * FROM kullanicilar WHERE type='Personel'");
			while(rs.next()) {
				obj=new Kullanici(rs.getString("Ad"),rs.getString("Soyad"),rs.getString("KullaniciAdi"),rs.getString("Sifre"),rs.getString("type"));
				list.add(obj);	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<AdminPer> get�slemlerList() throws SQLException{
		ArrayList<AdminPer> list=new ArrayList<>();
		AdminPer obj;
		try {
			st=con.createStatement();
			rs=st.executeQuery("SELECT * FROM islemler");
			while(rs.next()) {
				obj=new AdminPer(rs.getString("kullaniciadi"),rs.getString("Odenecek_tutar"),rs.getString("teslimsaati"),rs.getString("geriteslimsaati"));
				list.add(obj);	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public boolean personelEkle(String ad,String soyad,String kullaniciAdi,String sifre) throws SQLException {

		String QUERY="INSERT INTO kullanicilar"+"(Ad,Soyad,KullaniciAdi,Sifre,type) VALUES"+"(?,?,?,?,?)";
		boolean z=false;
		try {
			st=con.createStatement();
			preparedStatement=con.prepareStatement(QUERY);
			preparedStatement.setString(1, ad);
			preparedStatement.setString(2, soyad);
			preparedStatement.setString(3, kullaniciAdi);
			preparedStatement.setString(4, sifre);
			preparedStatement.setString(5, "Personel");
			preparedStatement.executeUpdate();
			z=true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		if(z) {
			return true;

		}else {
			return false;
		}
	}
	public boolean personelSil(String kullaniciAdi) throws SQLException {

		String QUERY="DELETE FROM kullanicilar WHERE KullaniciAdi = ?";
		boolean z=false;
		try {
			st=con.createStatement();
			preparedStatement=con.prepareStatement(QUERY);
			preparedStatement.setString(1, kullaniciAdi);
			preparedStatement.executeUpdate();
			z=true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		if(z) {
			return true;

		}else {
			return false;
		}
	}
	public boolean personelUpdate(String ad,String soyad,String kullaniciAdi, String sifre) {
		String QUERY="UPDATE kullanicilar SET Ad=?, Soyad=?,KullaniciAdi=?, Sifre=?, type=?";
		boolean ky=false;
		try {
			st=con.createStatement();
			preparedStatement=con.prepareStatement(QUERY);
			preparedStatement.setString(1, ad);
			preparedStatement.setString(2, soyad);
			preparedStatement.setString(3, kullaniciAdi);
			preparedStatement.setString(4, sifre);
			preparedStatement.setString(5, "Personel");
			preparedStatement.executeUpdate();
			ky=true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		if(ky) {
			return true;
		}else {
			return false;
		}
	}
}