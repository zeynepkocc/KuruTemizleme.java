package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import DBHelper.DbConnection;
import GUI.SepetOnayiGUI;

public class MusteriSepeti {
	private String urun;
	private int urun_fiyat;
	private int urun_tfiyat;
	private DbConnection conn=new DbConnection();
	Connection con=conn.connDb();
	Statement st=null;
	
	
	public MusteriSepeti(String urun, int urun_fiyat, int urun_tfiyat) {
		super();
		this.urun = urun;
		this.urun_fiyat = urun_fiyat;
		this.urun_tfiyat = urun_tfiyat;
	}

	public String getUrun() {
		return urun;
	}

	public void setUrun(String urun) {
		this.urun = urun;
	}

	public int getUrun_fiyat() {
		return urun_fiyat;
	}

	public void setUrun_fiyat(int urun_fiyat) {
		this.urun_fiyat = urun_fiyat;
	}

	public int getUrun_tfiyat() {
		return urun_tfiyat;
	}

	public void setUrun_tfiyat(int urun_tfiyat) {
		this.urun_tfiyat = urun_tfiyat;
	}
	public MusteriSepeti() {}

	ResultSet rs=null;
	PreparedStatement preparedStatement=null;

	public ArrayList<MusteriSepeti> getSepetList() throws SQLException{
		ArrayList<MusteriSepeti> list=new ArrayList<>();
		MusteriSepeti obj;
		try {
			st=con.createStatement();
			rs=st.executeQuery("SELECT * FROM musteri_sepeti");
			while(rs.next()) {
				obj=new MusteriSepeti(rs.getString("�r�n"),rs.getInt("�r�n_Adedi"),rs.getInt("�r�n_Tutar�"));
				list.add(obj);	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public boolean sepeteEkle(String urun, int urun_fiyat, int urun_tfiyat) throws SQLException {

		String QUERY="INSERT INTO musteri_sepeti"+"(�r�n, �r�n_Adedi, �r�n_Tutar�) VALUES"+"(?,?,?)";
		boolean z=false;
		try {
			st=con.createStatement();
			preparedStatement=con.prepareStatement(QUERY);
			preparedStatement.setString(1, urun);
			preparedStatement.setInt(2, urun_fiyat);
			preparedStatement.setInt(3, urun_tfiyat);
			preparedStatement.executeUpdate();
			z=true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		if(z) {
			return true;

		}else {
			return false;
		}
	}
	public boolean sepettenSil(String urun) throws SQLException {

		String QUERY="DELETE FROM musteri_sepeti WHERE �r�n = ?";
		boolean z=false;
		try {
			st=con.createStatement();
			preparedStatement=con.prepareStatement(QUERY);
			preparedStatement.setString(1, urun);
			preparedStatement.executeUpdate();
			z=true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		if(z) {
			return true;

		}else {
			return false;
		}
	}
}
