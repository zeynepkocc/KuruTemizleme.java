package Model;

public class Admin extends Kullanici{

	public Admin(String ad, String soyad, String kullaniciAdi, String sifre, String type) {
		super(ad, soyad, kullaniciAdi, sifre, type);
	}
	
	public Admin() {
	}
}
