package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import DBHelper.DbConnection;

public class AdminMus extends Admin{
	private DbConnection conn=new DbConnection();
	Connection con=conn.connDb();
	Statement st=null;
	ResultSet rs=null;
	PreparedStatement preparedStatement=null;
	
	public AdminMus() {}

	public AdminMus(String ad, String soyad, String kullaniciAdi, String sifre, String type) {
		super(ad, soyad, kullaniciAdi, sifre, type);
	}
	public ArrayList<Kullanici> getMusteriList() throws SQLException{
		ArrayList<Kullanici> list=new ArrayList<>();
		Kullanici obj;
		Connection con=conn.connDb();
		try {
			st=con.createStatement();
			rs=st.executeQuery("SELECT * FROM kullanicilar WHERE type='M��teri'");
			while(rs.next()) {
				obj=new Kullanici(rs.getString("Ad"),rs.getString("Soyad"),rs.getString("KullaniciAdi"),rs.getString("Sifre"),rs.getString("type"));
				list.add(obj);	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			st.close();
			rs.close();
			con.close();
		}
		return list;
	}
	public boolean MusteriSil(String kullaniciAdi) throws SQLException {
		String QUERY="DELETE FROM kullanicilar WHERE KullaniciAdi = ?";
		boolean z=false;
		try {
			st=con.createStatement();
			preparedStatement=con.prepareStatement(QUERY);
			preparedStatement.setString(1, kullaniciAdi);
			preparedStatement.executeUpdate();
			z=true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		if(z) {
			return true;

		}else {
			return false;
		}
	}
	public boolean musteriUpdate(String ad,String soyad,String kullaniciAdi, String sifre) {
		String QUERY="UPDATE kullanicilar SET Ad=?, Soyad=?,KullaniciAdi=?, Sifre=?, type=?";
		boolean ky=false;
		try {
			st=con.createStatement();
			preparedStatement=con.prepareStatement(QUERY);
			preparedStatement.setString(1, ad);
			preparedStatement.setString(2, soyad);
			preparedStatement.setString(3, kullaniciAdi);
			preparedStatement.setString(4, sifre);
			preparedStatement.setString(5, "M��teri");
			preparedStatement.executeUpdate();
			ky=true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		if(ky) {
			return true;
		}else {
			return false;
		}
	}
}
