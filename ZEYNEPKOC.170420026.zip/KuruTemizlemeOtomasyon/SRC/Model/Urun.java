package Model;

public class Urun {
	private String urun_adi;
	private int urun_fiyati;
	
	public Urun() {
	}
	public Urun(String urun_adi, int urun_fiyati) {
		super();
		this.urun_adi = urun_adi;
		this.urun_fiyati = urun_fiyati;
	}
	
	public String getUrun_adi() {
		return urun_adi;
	}
	public void setUrun_adi(String urun_adi) {
		this.urun_adi = urun_adi;
	}
	public int getUrun_fiyati() {
		return urun_fiyati;
	}
	public void setUrun_fiyati(int urun_fiyati) {
		this.urun_fiyati = urun_fiyati;
	}
}
