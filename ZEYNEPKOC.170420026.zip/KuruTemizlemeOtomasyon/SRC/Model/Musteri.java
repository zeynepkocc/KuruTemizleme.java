package Model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import DBHelper.DbConnection;

public class Musteri extends Kullanici{
	
	DbConnection conn=new DbConnection();
	Statement st=null;
	ResultSet rs=null;
	Connection con=conn.connDb();
	PreparedStatement preparedStatement=null;
	
	
	public Musteri() {
	}

	public Musteri(String ad, String soyad, String kullaniciAdi, String sifre, String type) {
		super(ad, soyad, kullaniciAdi, sifre, type);
	}
	public boolean kayit(String ad, String soyad, String kullaniciAdi, String sifre) throws SQLException{
		int sayim=0;
		boolean sayac=false;
		String QUERY="INSERT INTO kullanicilar "+ "(Ad,Soyad,KullaniciAdi,Sifre,type) VALUES"+"(?,?,?,?,?)";
		try {
			st=con.createStatement();
			rs=st.executeQuery("SELECT * FROM kullanicilar WHERE KullaniciAdi = '" + kullaniciAdi + "'");
			
			while(rs.next()) {
				sayac=true;
				JOptionPane.showMessageDialog(null,"Bu kullan�c� ad� �oktan al�nm��!");
				break;
			}
			if(!sayac) {
				preparedStatement=con.prepareStatement(QUERY);
				preparedStatement.setString(1, ad);
				preparedStatement.setString(2, soyad);
				preparedStatement.setString(3, kullaniciAdi);
				preparedStatement.setString(4, sifre);
				preparedStatement.setString(5, "M��teri");
				preparedStatement.executeUpdate();
			}
			sayim=1;
		}catch(SQLException e) {
			e.printStackTrace();
		}
		if(sayim==1) {
			return true;
		}
		else {
			return false;
		}
	}
}
