package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import DBHelper.DbConnection;

public class AdminUrun extends Urun {
	private DbConnection conn=new DbConnection();
	Connection con=conn.connDb();
	Statement st=null;
	
	public AdminUrun(String urun_adi, int urun_fiyati) {
		super(urun_adi, urun_fiyati);
	}

	public AdminUrun() {}

	ResultSet rs=null;
	PreparedStatement preparedStatement=null;

	public ArrayList<Urun> getUrunlerList() throws SQLException{
		ArrayList<Urun> list=new ArrayList<>();
		Urun obj;
		try {
			st=con.createStatement();
			rs=st.executeQuery("SELECT * FROM urunler");
			while(rs.next()) {
				obj=new Urun(rs.getString("Urun Tipi"),rs.getInt("Urun Fiyati"));
				list.add(obj);	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
}
