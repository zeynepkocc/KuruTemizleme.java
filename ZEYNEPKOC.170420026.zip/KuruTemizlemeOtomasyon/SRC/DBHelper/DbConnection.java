package DBHelper;
import java.sql.*;

public class DbConnection {
	Connection connect=null;
	
	public DbConnection() {
		
	}
	
	public Connection connDb() {
		try {
			this.connect=DriverManager.getConnection("jdbc:mysql://localhost:3306/kuru_temizleme?user=root&password=Ada-1906");
			return connect;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connect;
	}
}
