package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

import Model.Admin;
import Model.AdminMus;
import Model.AdminPer;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.Font;
import java.sql.SQLException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;

public class A_MusterilerGUI extends JFrame {

	private JPanel a_muspane;
	private JTextField kad1;
	private JTable musteritable;
	private DefaultTableModel musteriModel=null;
	private Object[] musteriVeri=null;
	static AdminMus admin=new AdminMus();
	private JButton btnNewButton_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminMus a=new AdminMus();
					A_MusterilerGUI frame = new A_MusterilerGUI(a);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	public A_MusterilerGUI(AdminMus admin) throws SQLException {
		setResizable(false);
		
		musteriModel = new DefaultTableModel();
		Object[] strMusteriAdi = new Object[4];
		strMusteriAdi[0]="Ad";
		strMusteriAdi[1]="Soyad";
		strMusteriAdi[2]="Kullan�c� Ad�";
		strMusteriAdi[3]="�ifre";
		musteriModel.setColumnIdentifiers(strMusteriAdi);
		
		musteriVeri=new Object[4];
		for(int i=0; i<admin.getMusteriList().size(); i++) {
			musteriVeri[0]=admin.getMusteriList().get(i).getAd();
			musteriVeri[1]=admin.getMusteriList().get(i).getSoyad();
			musteriVeri[2]=admin.getMusteriList().get(i).getKullaniciAdi();
			musteriVeri[3]=admin.getMusteriList().get(i).getSifre();
			musteriModel.addRow(musteriVeri);
		}

		setTitle("M\u00FC\u015Fteri Bilgileri");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 592, 552);
		a_muspane = new JPanel();
		a_muspane.setBackground(new Color(255, 250, 205));
		a_muspane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(a_muspane);
		a_muspane.setLayout(null);
		
		kad1 = new JTextField();
		kad1.setBounds(108, 439, 184, 19);
		a_muspane.add(kad1);
		kad1.setColumns(10);
		
		JButton btnNewButton = new JButton("KULLANICIYI S\u0130L");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(kad1.getText().length()==0) {
					JOptionPane.showMessageDialog(null, "L�tfen Silmek �stedi�iniz M��terinin Kullan�c� Ad�n� Giriniz!");
				}else {
					int cont=0;
					try {
						String kad2=kad1.getText();
						admin.MusteriSil(kad2);
						cont=1;
						if(cont==1) {
							kad1.setText(null);
							updateMusteriModel();
							JOptionPane.showMessageDialog(null, "M��teri Ba�ar�yla Silindi!");
						}
					}catch (SQLException e1) {
						e1.printStackTrace();
					}
					
				}
			}
		});
		btnNewButton.setBackground(new Color(255, 204, 102));
		btnNewButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
		btnNewButton.setBounds(10, 468, 282, 37);
		a_muspane.add(btnNewButton);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 10, 558, 406);
		a_muspane.add(tabbedPane);
		
		JPanel p3 = new JPanel();
		p3.setBackground(new Color(255, 204, 102));
		tabbedPane.addTab(" M��teri Bilgileri", null, p3, null);
		p3.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 534, 359);
		p3.add(scrollPane);
		
		musteritable = new JTable(musteriModel);
		musteritable.setBackground(new Color(255, 250, 205));
		scrollPane.setViewportView(musteritable);
		musteritable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				try {
					kad1.setText(musteritable.getValueAt(musteritable.getSelectedRow(), 2).toString());
				}catch(Exception er) {
					
				}
			}
		});
		musteritable.getModel().addTableModelListener(new TableModelListener() {

			@Override
			public void tableChanged(TableModelEvent e) {
				if(e.getType()==TableModelEvent.UPDATE) {
					String k_adi=musteritable.getValueAt(musteritable.getSelectedRow(), 0).toString();
					String k_soyadi=musteritable.getValueAt(musteritable.getSelectedRow(), 1).toString();
					String k_pno=musteritable.getValueAt(musteritable.getSelectedRow(), 2).toString();
					int kont=0;
					String k_sifre=musteritable.getValueAt(musteritable.getSelectedRow(), 3).toString();
					try {
						admin.musteriUpdate(k_adi, k_soyadi, k_pno, k_sifre);
						kont=1;
						if(kont==0) {
							JOptionPane.showMessageDialog(null, "Hata!");
						}
					}catch(Exception err) {
						err.printStackTrace();
					}
				}
				
			}
			
		});
		
		JLabel lblNewLabel_3 = new JLabel("KULLANICI ADI:");
		lblNewLabel_3.setFont(new Font("Segoe UI", Font.BOLD, 12));
		lblNewLabel_3.setBounds(10, 441, 118, 13);
		a_muspane.add(lblNewLabel_3);
		
		btnNewButton_1 = new JButton("Ana Ekrana Geri D\u00F6n");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminGUI a=new AdminGUI(admin);
				a.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBackground(new Color(255, 204, 102));
		btnNewButton_1.setFont(new Font("Segoe UI", Font.BOLD, 10));
		btnNewButton_1.setToolTipText("");
		btnNewButton_1.setBounds(425, 473, 143, 29);
		a_muspane.add(btnNewButton_1);
		this.setLocationRelativeTo(null);
	}
	public void updateMusteriModel() throws SQLException{
		DefaultTableModel temizle=(DefaultTableModel) musteritable.getModel();
		temizle.setRowCount(0);
		for(int i=0; i<admin.getMusteriList().size(); i++) {
			musteriVeri[0]=admin.getMusteriList().get(i).getAd();
			musteriVeri[1]=admin.getMusteriList().get(i).getSoyad();
			musteriVeri[2]=admin.getMusteriList().get(i).getKullaniciAdi();
			musteriVeri[3]=admin.getMusteriList().get(i).getSifre();
			musteriModel.addRow(musteriVeri);
		}
	}
}
