package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import DBHelper.DbConnection;
import Model.Kullanici;
import Model.MusteriSepeti;

import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class MusteriGUI extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private DefaultTableModel sepetModel=null;
	private Object[] sepetVeri=null;
	private JTextField sepettext;
	private int toplam;
	static MusteriSepeti ms=new MusteriSepeti();
	static Kullanici k=new Kullanici();
	private String tp;
	private JTextField isim;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MusteriSepeti ms = new MusteriSepeti();
					MusteriGUI frame = new MusteriGUI(ms);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	
	public MusteriGUI(MusteriSepeti ms) throws SQLException {
		sepetModel = new DefaultTableModel();
		Object[] strsepet = new Object[3];
		strsepet[0]="�r�n";
		strsepet[1]="�r�n Adedi";
		strsepet[2]="�r�n Tutar�";
		sepetModel.setColumnIdentifiers(strsepet);
		sepetVeri=new Object[3];
		for(int i=0; i<ms.getSepetList().size(); i++) {
			sepetVeri[0]=ms.getSepetList().get(i).getUrun();
			sepetVeri[1]=ms.getSepetList().get(i).getUrun_fiyat();
			sepetVeri[2]=ms.getSepetList().get(i).getUrun_tfiyat();
			sepetModel.addRow(sepetVeri);
		}
		
		setResizable(false);
		String[] adet= {"1","2","3"};
		setTitle("M\u00FC\u015Fteri Paneli");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1020, 550);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 205));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		this.setLocationRelativeTo(null);
		JLabel l1 = new JLabel(new ImageIcon(getClass().getResource("abiye.png")));
		l1.setBounds(10, 10, 100, 100);
		contentPane.add(l1);
		
		JLabel l2 = new JLabel(new ImageIcon(getClass().getResource("ceket.png")));
		l2.setBounds(120, 10, 100, 100);
		contentPane.add(l2);
		
		JLabel lblNewLabel_2 = new JLabel(new ImageIcon(getClass().getResource("etek.png")));
		lblNewLabel_2.setBounds(340, 10, 100, 100);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_5 = new JLabel(new ImageIcon(getClass().getResource("g�mlek.png")));
		lblNewLabel_5.setBounds(670, 10, 100, 100);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel = new JLabel(new ImageIcon(getClass().getResource("cuppe.png")));
		lblNewLabel.setBounds(230, 10, 100, 100);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel(new ImageIcon(getClass().getResource("fular.png")));
		lblNewLabel_1.setBounds(450, 10, 100, 100);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel(new ImageIcon(getClass().getResource("gelin.png")));
		lblNewLabel_3.setBounds(560, 10, 100, 100);
		contentPane.add(lblNewLabel_3);
		
		JComboBox comboBox = new JComboBox(adet);
		comboBox.setBounds(60, 143, 50, 20);
		comboBox.setFont(new Font("Segoe UI", Font.BOLD, 12));
		comboBox.setBackground(new Color(255, 218, 185));
		contentPane.add(comboBox);
		
		JButton btnNewButton = new JButton("EKLE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					try {
						int fiyat = 0;
						int sayi=0;
						String h = (String)comboBox.getSelectedItem();
						if(h=="1") {
							sayi=1;
							fiyat=180*1;
						}if(h=="2") {
							sayi=2;
							fiyat=180*2;
						}if(h=="3") {
							sayi=3;
							fiyat=180*3;
						}
						ms.sepeteEkle("Abiye", sayi, fiyat);
						updateSepetModel();
						toplam=toplam+fiyat;
						getSepettext().setText(toplam+" TL");
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
			}
		});
		btnNewButton.setBounds(10, 175, 100, 27);
		btnNewButton.setBackground(new Color(255, 204, 102));
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_4 = new JLabel("AB\u0130YE");
		lblNewLabel_4.setBounds(10, 120, 100, 13);
		lblNewLabel_4.setForeground(new Color(0, 0, 0));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("Segoe UI", Font.BOLD, 13));
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_4_1 = new JLabel("CEKET");
		lblNewLabel_4_1.setBounds(120, 121, 100, 13);
		lblNewLabel_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1.setFont(new Font("Segoe UI", Font.BOLD, 13));
		contentPane.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_4_2 = new JLabel("C\u00DCPPE/KEP");
		lblNewLabel_4_2.setBounds(230, 120, 100, 13);
		lblNewLabel_4_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_2.setFont(new Font("Segoe UI", Font.BOLD, 13));
		contentPane.add(lblNewLabel_4_2);
		
		JLabel lblNewLabel_4_3 = new JLabel("ETEK");
		lblNewLabel_4_3.setBounds(340, 120, 100, 13);
		lblNewLabel_4_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_3.setFont(new Font("Segoe UI", Font.BOLD, 13));
		contentPane.add(lblNewLabel_4_3);
		
		JLabel lblNewLabel_4_4 = new JLabel("FULAR");
		lblNewLabel_4_4.setBounds(450, 120, 100, 13);
		lblNewLabel_4_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_4.setFont(new Font("Segoe UI", Font.BOLD, 13));
		contentPane.add(lblNewLabel_4_4);
		
		JLabel lblNewLabel_4_5 = new JLabel("GEL\u0130NL\u0130K");
		lblNewLabel_4_5.setBounds(560, 120, 100, 13);
		lblNewLabel_4_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_5.setFont(new Font("Segoe UI", Font.BOLD, 13));
		contentPane.add(lblNewLabel_4_5);
		
		JLabel lblNewLabel_4_6 = new JLabel("G\u00D6MLEK");
		lblNewLabel_4_6.setBounds(670, 120, 100, 13);
		lblNewLabel_4_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_6.setFont(new Font("Segoe UI", Font.BOLD, 13));
		contentPane.add(lblNewLabel_4_6);
		
		JComboBox comboBox_1 = new JComboBox(adet);
		comboBox_1.setBounds(170, 143, 50, 20);
		comboBox_1.setFont(new Font("Segoe UI", Font.BOLD, 12));
		comboBox_1.setBackground(new Color(255, 218, 185));
		contentPane.add(comboBox_1);
		
		JButton btnNewButton_1 = new JButton("EKLE");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int fiyat = 0;
					int sayi=0;
					String h = (String)comboBox_1.getSelectedItem();
					if(h=="1") {
						sayi=1;
						fiyat=50*1;
					}if(h=="2") {
						sayi=2;
						fiyat=50*2;
					}if(h=="3") {
						sayi=3;
						fiyat=50*3;
					}
					ms.sepeteEkle("Ceket", sayi, fiyat);
					updateSepetModel();
					toplam=toplam+fiyat;
					getSepettext().setText(toplam+" TL");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_1.setBounds(120, 175, 100, 27);
		btnNewButton_1.setBackground(new Color(255, 204, 102));
		contentPane.add(btnNewButton_1);
		
		
		JComboBox comboBox_2 = new JComboBox(adet);
		comboBox_2.setBounds(280, 143, 50, 20);
		comboBox_2.setFont(new Font("Segoe UI", Font.BOLD, 12));
		comboBox_2.setBackground(new Color(255, 218, 185));
		contentPane.add(comboBox_2);
		JButton btnNewButton_2 = new JButton("EKLE");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int fiyat = 0;
					int sayi=0;
					String h = (String)comboBox_2.getSelectedItem();
					if(h=="1") {
						sayi=1;
						fiyat=75*1;
					}if(h=="2") {
						sayi=2;
						fiyat=75*2;
					}if(h=="3") {
						sayi=3;
						fiyat=75*3;
					}
					ms.sepeteEkle("C�ppe&Kep", sayi, fiyat);
					updateSepetModel();
					toplam=toplam+fiyat;
					getSepettext().setText(toplam+" TL");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_2.setBounds(230, 175, 100, 27);
		btnNewButton_2.setBackground(new Color(255, 204, 102));
		contentPane.add(btnNewButton_2);
		
		JComboBox comboBox_3 = new JComboBox(adet);
		comboBox_3.setBounds(390, 143, 50, 20);
		comboBox_3.setFont(new Font("Segoe UI", Font.BOLD, 12));
		comboBox_3.setBackground(new Color(255, 218, 185));
		contentPane.add(comboBox_3);
		
		JButton btnNewButton_3 = new JButton("EKLE");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int fiyat = 0;
					int sayi=0;
					String h = (String)comboBox_3.getSelectedItem();
					if(h=="1") {
						sayi=1;
						fiyat=40*1;
					}if(h=="2") {
						sayi=2;
						fiyat=40*2;
					}if(h=="3") {
						sayi=3;
						fiyat=40*3;
					}
					ms.sepeteEkle("Etek", sayi, fiyat);
					updateSepetModel();
					toplam=toplam+fiyat;
					getSepettext().setText(toplam+" TL");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_3.setBounds(340, 175, 100, 27);
		btnNewButton_3.setBackground(new Color(255, 204, 102));
		contentPane.add(btnNewButton_3);
		
		JComboBox comboBox_4 = new JComboBox(adet);
		comboBox_4.setBounds(500, 143, 50, 20);
		comboBox_4.setFont(new Font("Segoe UI", Font.BOLD, 12));
		comboBox_4.setBackground(new Color(255, 218, 185));
		contentPane.add(comboBox_4);
		JButton btnNewButton_4 = new JButton("EKLE");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int fiyat = 0;
					int sayi=0;
					String h = (String)comboBox_4.getSelectedItem();
					if(h=="1") {
						sayi=1;
						fiyat=20*1;
					}if(h=="2") {
						sayi=2;
						fiyat=20*2;
					}if(h=="3") {
						sayi=3;
						fiyat=20*3;
					}
					ms.sepeteEkle("Fular", sayi, fiyat);
					updateSepetModel();
					toplam=toplam+fiyat;
					getSepettext().setText(toplam+" TL");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_4.setBounds(450, 175, 100, 27);
		btnNewButton_4.setBackground(new Color(255, 204, 102));
		contentPane.add(btnNewButton_4);
		
		JComboBox comboBox_5 = new JComboBox(adet);
		comboBox_5.setBounds(610, 143, 50, 20);
		comboBox_5.setFont(new Font("Segoe UI", Font.BOLD, 12));
		comboBox_5.setBackground(new Color(255, 218, 185));
		contentPane.add(comboBox_5);
		JButton btnNewButton_5 = new JButton("EKLE");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int fiyat = 0;
					int sayi=0;
					String h = (String)comboBox_5.getSelectedItem();
					if(h=="1") {
						sayi=1;
						fiyat=400*1;
					}if(h=="2") {
						sayi=2;
						fiyat=400*2;
					}if(h=="3") {
						sayi=3;
						fiyat=400*3;
					}
					ms.sepeteEkle("Gelinlik", sayi, fiyat);
					updateSepetModel();
					toplam=toplam+fiyat;
					getSepettext().setText(toplam+" TL");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_5.setBounds(560, 175, 100, 27);
		btnNewButton_5.setBackground(new Color(255, 204, 102));
		contentPane.add(btnNewButton_5);
		
		JComboBox comboBox_6 = new JComboBox(adet);
		comboBox_6.setBounds(720, 143, 50, 20);
		comboBox_6.setFont(new Font("Segoe UI", Font.BOLD, 12));
		comboBox_6.setBackground(new Color(255, 218, 185));
		contentPane.add(comboBox_6);
		JButton btnNewButton_6 = new JButton("EKLE");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int fiyat = 0;
					int sayi=0;
					String h = (String)comboBox_6.getSelectedItem();
					if(h=="1") {
						sayi=1;
						fiyat=50*1;
					}if(h=="2") {
						sayi=2;
						fiyat=50*2;
					}if(h=="3") {
						sayi=3;
						fiyat=50*3;
					}
					ms.sepeteEkle("G�mlek", sayi, fiyat);
					updateSepetModel();
					toplam=toplam+fiyat;
					getSepettext().setText(toplam+" TL");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_6.setBounds(670, 175, 100, 27);
		btnNewButton_6.setBackground(new Color(255, 204, 102));
		contentPane.add(btnNewButton_6);
		
		JLabel lblNewLabel_6 = new JLabel(new ImageIcon(getClass().getResource("kazak.png")));
		lblNewLabel_6.setBounds(10, 228, 100, 100);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_6_1 = new JLabel(new ImageIcon(getClass().getResource("kravat.png")));
		lblNewLabel_6_1.setBounds(120, 228, 100, 100);
		contentPane.add(lblNewLabel_6_1);
		
		JLabel lblNewLabel_6_2 = new JLabel(new ImageIcon(getClass().getResource("mont.png")));
		lblNewLabel_6_2.setBounds(230, 228, 100, 100);
		contentPane.add(lblNewLabel_6_2);
		
		JLabel lblNewLabel_6_3 = new JLabel(new ImageIcon(getClass().getResource("palto.png")));
		lblNewLabel_6_3.setBounds(340, 228, 100, 100);
		contentPane.add(lblNewLabel_6_3);
		
		JLabel lblNewLabel_6_4 = new JLabel(new ImageIcon(getClass().getResource("pantolon.png")));
		lblNewLabel_6_4.setBounds(898, 10, 100, 100);
		contentPane.add(lblNewLabel_6_4);
		
		JLabel lblNewLabel_6_5 = new JLabel(new ImageIcon(getClass().getResource("tak�melbise.png")));
		lblNewLabel_6_5.setBounds(788, 10, 100, 100);
		contentPane.add(lblNewLabel_6_5);
		
		JLabel lblNewLabel_4_7 = new JLabel("KAZAK");
		lblNewLabel_4_7.setBounds(10, 338, 100, 13);
		lblNewLabel_4_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_7.setFont(new Font("Segoe UI", Font.BOLD, 13));
		contentPane.add(lblNewLabel_4_7);
		
		JLabel lblNewLabel_4_8 = new JLabel("KRAVAT");
		lblNewLabel_4_8.setBounds(120, 338, 100, 13);
		lblNewLabel_4_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_8.setFont(new Font("Segoe UI", Font.BOLD, 13));
		contentPane.add(lblNewLabel_4_8);
		
		JLabel lblNewLabel_4_9 = new JLabel("MONT");
		lblNewLabel_4_9.setBounds(230, 338, 100, 13);
		lblNewLabel_4_9.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_9.setFont(new Font("Segoe UI", Font.BOLD, 13));
		contentPane.add(lblNewLabel_4_9);
		
		JLabel lblNewLabel_4_10 = new JLabel("PALTO");
		lblNewLabel_4_10.setBounds(340, 338, 100, 13);
		lblNewLabel_4_10.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_10.setFont(new Font("Segoe UI", Font.BOLD, 13));
		contentPane.add(lblNewLabel_4_10);
		
		JLabel lblNewLabel_4_11 = new JLabel("PANTOLON");
		lblNewLabel_4_11.setBounds(898, 120, 100, 13);
		lblNewLabel_4_11.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_11.setFont(new Font("Segoe UI", Font.BOLD, 13));
		contentPane.add(lblNewLabel_4_11);
		
		JLabel lblNewLabel_4_12 = new JLabel("TAKIM ELB\u0130SE");
		lblNewLabel_4_12.setBounds(788, 120, 100, 13);
		lblNewLabel_4_12.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_12.setFont(new Font("Segoe UI", Font.BOLD, 13));
		contentPane.add(lblNewLabel_4_12);
		
		JComboBox comboBox_7 = new JComboBox(adet);
		comboBox_7.setBounds(838, 143, 50, 20);
		comboBox_7.setFont(new Font("Segoe UI", Font.BOLD, 12));
		comboBox_7.setBackground(new Color(255, 218, 185));
		contentPane.add(comboBox_7);		
		JButton btnNewButton_11 = new JButton("EKLE");
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int fiyat = 0;
					int sayi=0;
					String h = (String)comboBox_7.getSelectedItem();
					if(h=="1") {
						sayi=1;
						fiyat=200*1;
					}if(h=="2") {
						sayi=2;
						fiyat=200*2;
					}if(h=="3") {
						sayi=3;
						fiyat=200*3;
					}
					ms.sepeteEkle("Tak�m Elbise", sayi, fiyat);
					updateSepetModel();
					toplam=toplam+fiyat;
					getSepettext().setText(toplam+" TL");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_11.setBounds(788, 175, 100, 27);
		btnNewButton_11.setBackground(new Color(255, 204, 102));
		contentPane.add(btnNewButton_11);
	
		JComboBox comboBox_7_1 = new JComboBox(adet);
		comboBox_7_1.setBounds(946, 143, 50, 20);
		comboBox_7_1.setFont(new Font("Segoe UI", Font.BOLD, 12));
		comboBox_7_1.setBackground(new Color(255, 218, 185));
		contentPane.add(comboBox_7_1);
		JButton btnNewButton_12 = new JButton("EKLE");
		btnNewButton_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int fiyat = 0;
					int sayi=0;
					String h = (String)comboBox_7_1.getSelectedItem();
					if(h=="1") {
						sayi=1;
						fiyat=75*1;
					}if(h=="2") {
						sayi=2;
						fiyat=75*2;
					}if(h=="3") {
						sayi=3;
						fiyat=75*3;
					}
					ms.sepeteEkle("Pantolon", sayi, fiyat);
					updateSepetModel();
					toplam=toplam+fiyat;
					getSepettext().setText(toplam+" TL");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_12.setBounds(898, 175, 100, 27);
		btnNewButton_12.setBackground(new Color(255, 204, 102));
		contentPane.add(btnNewButton_12);
		
		JComboBox comboBox_7_2 = new JComboBox(adet);
		comboBox_7_2.setBounds(60, 364, 50, 20);
		comboBox_7_2.setFont(new Font("Segoe UI", Font.BOLD, 12));
		comboBox_7_2.setBackground(new Color(255, 218, 185));
		contentPane.add(comboBox_7_2);		
		JButton btnNewButton_7 = new JButton("EKLE");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int fiyat = 0;
					int sayi=0;
					String h = (String)comboBox_7_2.getSelectedItem();
					if(h=="1") {
						sayi=1;
						fiyat=40*1;
					}if(h=="2") {
						sayi=2;
						fiyat=40*2;
					}if(h=="3") {
						sayi=3;
						fiyat=40*3;
					}
					ms.sepeteEkle("Kazak", sayi, fiyat);
					updateSepetModel();
					toplam=toplam+fiyat;
					getSepettext().setText(toplam+" TL");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_7.setBounds(10, 391, 100, 27);
		btnNewButton_7.setBackground(new Color(255, 204, 102));
		contentPane.add(btnNewButton_7);
		
		JComboBox comboBox_7_3 = new JComboBox(adet);
		comboBox_7_3.setBounds(170, 364, 50, 20);
		comboBox_7_3.setFont(new Font("Segoe UI", Font.BOLD, 12));
		comboBox_7_3.setBackground(new Color(255, 218, 185));
		contentPane.add(comboBox_7_3);
		JButton btnNewButton_8 = new JButton("EKLE");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int fiyat = 0;
					int sayi=0;
					String h = (String)comboBox_7_3.getSelectedItem();
					if(h=="1") {
						sayi=1;
						fiyat=20*1;
					}if(h=="2") {
						sayi=2;
						fiyat=20*2;
					}if(h=="3") {
						sayi=3;
						fiyat=20*3;
					}
					ms.sepeteEkle("Kravat", sayi, fiyat);
					updateSepetModel();
					toplam=toplam+fiyat;
					getSepettext().setText(toplam+" TL");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_8.setBounds(120, 391, 100, 27);
		btnNewButton_8.setBackground(new Color(255, 204, 102));
		contentPane.add(btnNewButton_8);
		
		JComboBox comboBox_7_4 = new JComboBox(adet);
		comboBox_7_4.setBounds(280, 364, 50, 20);
		comboBox_7_4.setFont(new Font("Segoe UI", Font.BOLD, 12));
		comboBox_7_4.setBackground(new Color(255, 218, 185));
		contentPane.add(comboBox_7_4);
		JButton btnNewButton_9 = new JButton("EKLE");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int fiyat = 0;
					int sayi=0;
					String h = (String)comboBox_7_4.getSelectedItem();
					if(h=="1") {
						sayi=1;
						fiyat=120*1;
					}if(h=="2") {
						sayi=2;
						fiyat=120*2;
					}if(h=="3") {
						sayi=3;
						fiyat=120*3;
					}
					ms.sepeteEkle("Mont", sayi, fiyat);
					updateSepetModel();
					toplam=toplam+fiyat;
					getSepettext().setText(toplam+" TL");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_9.setBounds(230, 391, 100, 27);
		btnNewButton_9.setBackground(new Color(255, 204, 102));
		contentPane.add(btnNewButton_9);
		
		JComboBox comboBox_7_5 = new JComboBox(adet);
		comboBox_7_5.setBounds(390, 364, 50, 20);
		comboBox_7_5.setFont(new Font("Segoe UI", Font.BOLD, 12));
		comboBox_7_5.setBackground(new Color(255, 218, 185));
		contentPane.add(comboBox_7_5);
		JButton btnNewButton_10 = new JButton("EKLE");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int fiyat = 0;
					int sayi=0;
					String h = (String)comboBox_7_5.getSelectedItem();
					if(h=="1") {
						sayi=1;
						fiyat=80*1;
					}if(h=="2") {
						sayi=2;
						fiyat=80*2;
					}if(h=="3") {
						sayi=3;
						fiyat=80*3;
					}
					ms.sepeteEkle("Palto", sayi, fiyat);
					updateSepetModel();
					toplam=toplam+fiyat;
					getSepettext().setText(toplam+" TL");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_10.setBounds(340, 391, 100, 27);
		btnNewButton_10.setBackground(new Color(255, 204, 102));
		contentPane.add(btnNewButton_10);
		
		JLabel lblNewLabel_7 = new JLabel("180 TL");
		lblNewLabel_7.setBounds(10, 148, 45, 13);
		lblNewLabel_7.setForeground(new Color(178, 34, 34));
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_7_1 = new JLabel("50 TL");
		lblNewLabel_7_1.setBounds(120, 148, 45, 13);
		lblNewLabel_7_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7_1.setForeground(new Color(178, 34, 34));
		lblNewLabel_7_1.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		contentPane.add(lblNewLabel_7_1);
		
		JLabel lblNewLabel_7_2 = new JLabel("75 TL");
		lblNewLabel_7_2.setBounds(230, 148, 45, 13);
		lblNewLabel_7_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7_2.setForeground(new Color(178, 34, 34));
		lblNewLabel_7_2.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		contentPane.add(lblNewLabel_7_2);
		
		JLabel lblNewLabel_7_3 = new JLabel("40 TL");
		lblNewLabel_7_3.setBounds(340, 148, 45, 13);
		lblNewLabel_7_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7_3.setForeground(new Color(178, 34, 34));
		lblNewLabel_7_3.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		contentPane.add(lblNewLabel_7_3);
		
		JLabel lblNewLabel_7_4 = new JLabel("20 TL");
		lblNewLabel_7_4.setBounds(450, 148, 45, 13);
		lblNewLabel_7_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7_4.setForeground(new Color(178, 34, 34));
		lblNewLabel_7_4.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		contentPane.add(lblNewLabel_7_4);
		
		JLabel lblNewLabel_7_5 = new JLabel("40 TL");
		lblNewLabel_7_5.setBounds(10, 368, 45, 13);
		lblNewLabel_7_5.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7_5.setForeground(new Color(178, 34, 34));
		lblNewLabel_7_5.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		contentPane.add(lblNewLabel_7_5);
		
		JLabel lblNewLabel_7_6 = new JLabel("20 TL");
		lblNewLabel_7_6.setBounds(120, 368, 45, 13);
		lblNewLabel_7_6.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7_6.setForeground(new Color(178, 34, 34));
		lblNewLabel_7_6.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		contentPane.add(lblNewLabel_7_6);
		
		JLabel lblNewLabel_7_7 = new JLabel("120 TL");
		lblNewLabel_7_7.setBounds(230, 368, 45, 13);
		lblNewLabel_7_7.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7_7.setForeground(new Color(178, 34, 34));
		lblNewLabel_7_7.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		contentPane.add(lblNewLabel_7_7);
		
		JLabel lblNewLabel_7_8 = new JLabel("80 TL");
		lblNewLabel_7_8.setBounds(340, 368, 45, 13);
		lblNewLabel_7_8.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7_8.setForeground(new Color(178, 34, 34));
		lblNewLabel_7_8.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		contentPane.add(lblNewLabel_7_8);
		
		JLabel lblNewLabel_7_9 = new JLabel("75 TL");
		lblNewLabel_7_9.setBounds(898, 147, 45, 13);
		lblNewLabel_7_9.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7_9.setForeground(new Color(178, 34, 34));
		lblNewLabel_7_9.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		contentPane.add(lblNewLabel_7_9);
		
		JLabel lblNewLabel_7_10 = new JLabel("400 TL");
		lblNewLabel_7_10.setBounds(560, 148, 45, 13);
		lblNewLabel_7_10.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7_10.setForeground(new Color(178, 34, 34));
		lblNewLabel_7_10.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		contentPane.add(lblNewLabel_7_10);
		
		JLabel lblNewLabel_7_11 = new JLabel("200 TL");
		lblNewLabel_7_11.setBounds(788, 147, 45, 13);
		lblNewLabel_7_11.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7_11.setForeground(new Color(178, 34, 34));
		lblNewLabel_7_11.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		contentPane.add(lblNewLabel_7_11);
		
		JLabel lblNewLabel_7_12 = new JLabel("50 TL");
		lblNewLabel_7_12.setBounds(670, 148, 45, 13);
		lblNewLabel_7_12.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7_12.setForeground(new Color(178, 34, 34));
		lblNewLabel_7_12.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		contentPane.add(lblNewLabel_7_12);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(new Color(255, 204, 102));
		tabbedPane.setBounds(461, 228, 393, 225);
		contentPane.add(tabbedPane);
		
		JScrollPane scrollPane = new JScrollPane();
		tabbedPane.addTab("SEPET�M", null, scrollPane, null);
		
		table = new JTable(sepetModel);
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_13 = new JButton("Sepeti Bo\u015Falt");
		btnNewButton_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				while(sepetModel.getRowCount()>0) {
					for(int i=0; i<sepetModel.getRowCount(); i++) {
						try {
							String silinen=(String) table.getValueAt(i, 0);
							ms.sepettenSil(silinen);
							sepetModel.removeRow(i);
							toplam=0;
							getSepettext().setText(toplam+" TL");
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					}
				}
			}
		});
		
		btnNewButton_13.setBackground(new Color(240, 128, 128));
		btnNewButton_13.setFont(new Font("Segoe UI", Font.BOLD, 11));
		btnNewButton_13.setBounds(864, 368, 133, 27);
		contentPane.add(btnNewButton_13);
		
		JButton btnNewButton_13_1 = new JButton("Se\u00E7ili \u00DCr\u00FCn\u00FC Sil");
		btnNewButton_13_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(table.getSelectedRow()==-1) {
						JOptionPane.showMessageDialog(null, "L�tfen silmek istedi�iniz �r�n� se�iniz!");
					}else {
						String silinen=(String) table.getValueAt(table.getSelectedRow(), 0);
						ms.sepettenSil(silinen);
						int eksilen=(Integer) table.getValueAt(table.getSelectedRow(), 2);
						toplam=toplam-eksilen;
						getSepettext().setText(toplam+" TL");
						sepetModel.removeRow(table.getSelectedRow());
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_13_1.setBackground(new Color(240, 128, 128));
		btnNewButton_13_1.setFont(new Font("Segoe UI", Font.BOLD, 11));
		btnNewButton_13_1.setBounds(864, 331, 133, 27);
		contentPane.add(btnNewButton_13_1);
		
		JButton btnNewButton_14 = new JButton("SEPET\u0130 ONAYLA");
		btnNewButton_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DbConnection conn=new DbConnection();
				Connection con=conn.connDb();
				PreparedStatement preparedStatement=null;
				
				String QUERY = "CREATE TABLE IF NOT EXISTS admin LIKE musteri_sepeti"; 
				String 	QUERY2 = "INSERT admin SELECT * FROM musteri_sepeti ";
				String QUERY3="DELETE FROM musteri_sepeti";
				SepetOnayiGUI sp;
				try {
					preparedStatement=con.prepareStatement(QUERY);
					preparedStatement.executeUpdate();
					preparedStatement=con.prepareStatement(QUERY2);
					preparedStatement.executeUpdate();
					preparedStatement=con.prepareStatement(QUERY3);
					preparedStatement.executeUpdate();
					sp = new SepetOnayiGUI();
					sp.getOnaytext().setText(toplam+" TL");
					sp.getTxt().setText(isim.getText().toString());
					sp.setVisible(true);
					dispose();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_14.setBackground(new Color(152, 251, 152));
		btnNewButton_14.setFont(new Font("Segoe UI Black", Font.BOLD, 11));
		btnNewButton_14.setBounds(864, 405, 134, 52);
		contentPane.add(btnNewButton_14);
		
		JLabel lblNewLabel_8 = new JLabel("**TESL\u0130M G\u00DCN\u00DC SE\u00C7MEK \u0130\u00C7\u0130N SEPET\u0130 ONAYLA TU\u015EUNA BASINIZ!**");
		lblNewLabel_8.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_8.setBounds(461, 463, 413, 27);
		contentPane.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("\u0130\u015Flem g\u00F6rmesi i\u00E7in teslim etmek istedi\u011Finiz \u00FCr\u00FCn \u00E7e\u015Fidini ve adedini se\u00E7erek sepetinize");
		lblNewLabel_9.setFont(new Font("Segoe UI", Font.ITALIC, 12));
		lblNewLabel_9.setBounds(10, 428, 441, 34);
		contentPane.add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("ekleyiniz.(Her \u00FCr\u00FCnden en fazla 3 adet teslim edebilirsiniz!)");
		lblNewLabel_10.setFont(new Font("Segoe UI", Font.ITALIC, 12));
		lblNewLabel_10.setBounds(10, 451, 441, 20);
		contentPane.add(lblNewLabel_10);
		
		sepettext = new JTextField();
		getSepettext().setText("0 TL");
		getSepettext().setHorizontalAlignment(SwingConstants.CENTER);
		getSepettext().setForeground(Color.BLUE);
		getSepettext().setFont(new Font("Segoe UI", Font.BOLD, 14));
		getSepettext().setBounds(864, 274, 133, 47);
		contentPane.add(getSepettext());
		getSepettext().setColumns(10);
		
		JLabel lblNewLabel_11 = new JLabel("TOPLAM SEPET TUTARI");
		lblNewLabel_11.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		lblNewLabel_11.setBounds(864, 251, 133, 13);
		contentPane.add(lblNewLabel_11);
		
		JLabel lblNewLabel_13 = new JLabel("Kullan\u0131c\u0131: ");
		lblNewLabel_13.setFont(new Font("Segoe UI", Font.BOLD, 13));
		lblNewLabel_13.setBounds(10, 490, 68, 13);
		contentPane.add(lblNewLabel_13);
		
		isim = new JTextField();
		getIsim().setBounds(72, 485, 110, 20);
		contentPane.add(getIsim());
		getIsim().setColumns(10);

		tp=getSepettext().getText();
	}
	public String getTp() {
		return tp;
	}
	public int getToplam() {
		return toplam;
	}
	public void setToplam(int toplam) {
		this.toplam=toplam;
	}

	public void updateSepetModel() throws SQLException{
		DefaultTableModel temizle=(DefaultTableModel) table.getModel();
		temizle.setRowCount(0);
		for(int i=0; i<ms.getSepetList().size(); i++) {
			sepetVeri[0]=ms.getSepetList().get(i).getUrun();
			sepetVeri[1]=ms.getSepetList().get(i).getUrun_fiyat();
			sepetVeri[2]=ms.getSepetList().get(i).getUrun_tfiyat();
			sepetModel.addRow(sepetVeri);
		}
	}

	public JTextField getSepettext() {
		return sepettext;
	}

	public JTextField getIsim() {
		return isim;
	}
}
