package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import DBHelper.DbConnection;
import Model.Kullanici;
import Model.MusteriSepeti;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class SepetOnayiGUI extends JFrame {

	private JPanel contentPane;
	private DefaultTableModel onayModel=null;
	private Object[] onayVeri=null;
	private DefaultTableModel randevuModel=null;
	private Object[] randevuVeri=null;
	private String urun;
	private int urun_fiyat;
	private int urun_adet;
	private DbConnection conn=new DbConnection();
	Connection con=conn.connDb();
	Statement st=null;
	ResultSet rs=null;
	PreparedStatement preparedStatement=null;
	private JTable table;
	private JTextField onaytext;
	private JTable table_1;
	private JTextField textField;
	private String giris;
	private String cikis;
	private JTextField textField_1;
	private JTextField txt;
	
	public SepetOnayiGUI(String urun, int urun_fiyat, int urun_adet) throws HeadlessException {
		super();
		this.urun = urun;
		this.urun_fiyat = urun_fiyat;
		this.urun_adet = urun_adet;
	}
	public SepetOnayiGUI(String giris, String cikis) throws HeadlessException{
		super();
		this.giris=giris;
		this.cikis=cikis;
	}
	public String getCikis() {
		return cikis;
	}
	public String getGiris() {
		return giris;
	}
	public void setCikis(String cikis) {
		this.cikis=cikis;
	}
	public void setGiris(String giris) {
		this.giris=giris;
	}
	public String getUrun() {
		return urun;
	}

	public void setUrun(String urun) {
		this.urun = urun;
	}

	public int getUrun_fiyat() {
		return urun_fiyat;
	}

	public void setUrun_fiyat(int urun_fiyat) {
		this.urun_fiyat = urun_fiyat;
	}

	public int getUrun_adet() {
		return urun_adet;
	}

	public void setUrun_adet(int urun_adet) {
		this.urun_adet = urun_adet;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SepetOnayiGUI frame = new SepetOnayiGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public ArrayList<SepetOnayiGUI> getOnayList() throws SQLException{
		ArrayList<SepetOnayiGUI> list=new ArrayList<>();
		SepetOnayiGUI obj;
		try {
			st=con.createStatement();
			rs=st.executeQuery("SELECT * FROM admin");
			while(rs.next()) {
				obj=new SepetOnayiGUI(rs.getString("�r�n"),rs.getInt("�r�n_Adedi"),rs.getInt("�r�n_Tutar�"));
				list.add(obj);	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<SepetOnayiGUI> getRandevuList() throws SQLException{
		ArrayList<SepetOnayiGUI> list=new ArrayList<>();
		SepetOnayiGUI obj;
		try {
			st=con.createStatement();
			rs=st.executeQuery("SELECT * FROM randevu");
			while(rs.next()) {
				obj=new SepetOnayiGUI(rs.getString("giris_saati"),rs.getString("cikis_saati"));
				list.add(obj);	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	public SepetOnayiGUI() throws SQLException {
		
		Kullanici k=new Kullanici();
		MusteriSepeti s=new MusteriSepeti();
		MusteriGUI m=new MusteriGUI(s);
		
		onayModel = new DefaultTableModel();
		Object[] strUrun = new Object[3];
		strUrun[0]="�R�N";
		strUrun[1]="�R�N ADED�";
		strUrun[2]="F�YAT";
		onayModel.setColumnIdentifiers(strUrun);
		
		onayVeri=new Object[3];
		for(int i=0; i<getOnayList().size(); i++) {
			onayVeri[0]=getOnayList().get(i).getUrun();
			onayVeri[1]=getOnayList().get(i).getUrun_fiyat();
			onayVeri[2]=getOnayList().get(i).getUrun_adet();
			onayModel.addRow(onayVeri);
		}
		
		randevuModel=new DefaultTableModel();
		Object[] strrandevu=new Object[2];
		strrandevu[0]="Teslim Edilen Saat";
		strrandevu[1]="Teslim Al�nan Saat";
		randevuModel.setColumnIdentifiers(strrandevu);
		
		randevuVeri=new Object[2];
		for(int i=0; i<getRandevuList().size(); i++) {
			randevuVeri[0]=getRandevuList().get(i).getGiris();
			randevuVeri[1]=getRandevuList().get(i).getCikis();
			randevuModel.addRow(randevuVeri);
		}
		
		
		setTitle("Sepet Onay\u0131");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 779, 585);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 205));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		this.setLocationRelativeTo(null);
		
		JPanel fis = new JPanel();
		fis.setBackground(new Color(255, 250, 205));
		fis.setBounds(381, 10, 380, 528);
		contentPane.add(fis);
		fis.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 10, 360, 351);
		fis.add(tabbedPane);
		
		JScrollPane scrollPane = new JScrollPane();
		tabbedPane.addTab("��lem i�in se�ilen �r�nler", null, scrollPane, null);
		
		table = new JTable(onayModel);
		scrollPane.setViewportView(table);
		
		onaytext = new JTextField();
		getOnaytext().setFont(new Font("Segoe UI", Font.ITALIC, 13));
		getOnaytext().setBounds(10, 394, 169, 46);
		fis.add(getOnaytext());
		getOnaytext().setColumns(10);
		getOnaytext().setText(m.getTp());
		
		JButton btnSatnAlmayOnayla = new JButton("SATIN ALMAYI ONAYLA");
		btnSatnAlmayOnayla.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String QUERY="INSERT INTO islemler "+ "(kullaniciadi,Odenecek_tutar,teslimsaati,geriteslimsaati) VALUES"+"(?,?,?,?)";
				try {
					preparedStatement=con.prepareStatement(QUERY);
					preparedStatement.setString(1, txt.getText());
					preparedStatement.setString(2, onaytext.getText());
					preparedStatement.setString(3, textField.getText());
					preparedStatement.setString(4, textField_1.getText());
					preparedStatement.executeUpdate();
					JOptionPane.showMessageDialog(null, "��leminiz ba�ar�yla ger�ekle�ti. Bizi tercih etti�iniz i�in te�ekk�r ederiz!");
					System.exit(1);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnSatnAlmayOnayla.setFont(new Font("Segoe UI", Font.BOLD, 12));
		btnSatnAlmayOnayla.setBackground(new Color(144, 238, 144));
		btnSatnAlmayOnayla.setBounds(189, 395, 181, 45);
		fis.add(btnSatnAlmayOnayla);
		
		JLabel lblNewLabel = new JLabel("TOPLAM SEPET TUTARI");
		lblNewLabel.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		lblNewLabel.setBounds(10, 371, 169, 13);
		fis.add(lblNewLabel);
		
		JButton geributon = new JButton("Sepete Geri D\u00F6n");
		geributon.setBounds(237, 485, 133, 33);
		fis.add(geributon);
		geributon.setFont(new Font("Segoe UI", Font.BOLD, 11));
		geributon.setBackground(new Color(255, 204, 102));
		
		txt = new JTextField();
		getTxt().setBounds(10, 486, 169, 33);
		fis.add(getTxt());
		getTxt().setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("M\u00FC\u015Fteri Kullan\u0131c\u0131 Ad\u0131");
		lblNewLabel_4.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		lblNewLabel_4.setBounds(10, 463, 169, 13);
		fis.add(lblNewLabel_4);
		geributon.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String 	QUERY = "INSERT musteri_sepeti SELECT * FROM admin";
				String QUERY2="DELETE FROM admin";
				MusteriSepeti m;
				MusteriGUI ms;
				try {
					preparedStatement=con.prepareStatement(QUERY);
					preparedStatement.executeUpdate();
					preparedStatement=con.prepareStatement(QUERY2);
					preparedStatement.executeUpdate();
					m=new MusteriSepeti();
					ms = new MusteriGUI(m);
					ms.getSepettext().setText(onaytext.getText().toString());
					ms.setVisible(true);
					dispose();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}

			}
		});
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 250, 205));
		panel.setBounds(10, 10, 361, 528);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.setBounds(0, 10, 360, 351);
		panel.add(tabbedPane_1);
		
		
		JScrollPane scrollPane_1 = new JScrollPane();
		tabbedPane_1.addTab("�r�n� Teslim Saati", null, scrollPane_1, null);
		
		table_1 = new JTable(randevuModel);
		scrollPane_1.setViewportView(table_1);
		table_1.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				try {
					textField.setText(table_1.getValueAt(table_1.getSelectedRow(), 0).toString());
					textField_1.setText(table_1.getValueAt(table_1.getSelectedRow(), 1).toString());
				}catch(Exception er) {
					er.printStackTrace();
				}
			}
		});
		
		textField = new JTextField();
		textField.setFont(new Font("Segoe UI", Font.ITALIC, 13));
		textField.setColumns(10);
		textField.setBounds(10, 394, 154, 38);
		panel.add(textField);
		
		JLabel lblNewLabel_1 = new JLabel("Se\u00E7ilen Teslim Saati");
		lblNewLabel_1.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		lblNewLabel_1.setBounds(10, 371, 171, 13);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("***Saat 17:00'dan sonra teslim edilen \u00FCr\u00FCnlerin");
		lblNewLabel_2.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 11));
		lblNewLabel_2.setBounds(0, 442, 255, 27);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("teslim saatleri bir ertesi g\u00FCnden ba\u015Flar.***");
		lblNewLabel_3.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 11));
		lblNewLabel_3.setBounds(0, 470, 255, 23);
		panel.add(lblNewLabel_3);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Segoe UI", Font.ITALIC, 13));
		textField_1.setColumns(10);
		textField_1.setBounds(197, 394, 154, 38);
		panel.add(textField_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Se\u00E7ilen Geri Teslim Saati");
		lblNewLabel_1_1.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 12));
		lblNewLabel_1_1.setBounds(200, 371, 160, 13);
		panel.add(lblNewLabel_1_1);
		this.setLocationRelativeTo(null);

	}
	public JTextField getOnaytext() {
		return onaytext;
	}
	public JTextField getTxt() {
		return txt;
	}
}
