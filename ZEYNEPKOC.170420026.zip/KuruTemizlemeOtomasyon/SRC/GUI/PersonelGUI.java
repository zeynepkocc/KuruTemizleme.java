package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import DBHelper.DbConnection;
import Model.AdminPer;
import java.awt.Color;
import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class PersonelGUI extends JFrame {

	private DbConnection conn=new DbConnection();
	private JPanel contentPane;
	private DefaultTableModel islemler=null;
	private Object[] islemVeri=null;
	Connection con=conn.connDb();
	Statement st=null;
	ResultSet rs=null;
	PreparedStatement preparedStatement=null;
	private String kullaniciadi;
	private String teslimsaat;
	private String gteslimsaat;
	private JTable table;
	
	public PersonelGUI(String kullaniciadi, String teslimsaat, String gteslimsaat) {
		this.kullaniciadi=kullaniciadi;
		this.teslimsaat=teslimsaat;
		this.gteslimsaat=gteslimsaat;
	}

	/**
	 * Launch the application.
	 */
	public String getKullaniciadi() {
		return kullaniciadi;
	}

	public void setKullaniciadi(String kullaniciadi) {
		this.kullaniciadi = kullaniciadi;
	}

	public String getTeslimsaat() {
		return teslimsaat;
	}

	public void setTeslimsaat(String teslimsaat) {
		this.teslimsaat = teslimsaat;
	}

	public String getGteslimsaat() {
		return gteslimsaat;
	}

	public void setGteslimsaat(String gteslimsaat) {
		this.gteslimsaat = gteslimsaat;
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PersonelGUI frame = new PersonelGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ArrayList<PersonelGUI> get�slemlerList() throws SQLException{
		ArrayList<PersonelGUI> list=new ArrayList<>();
		PersonelGUI obj;
		try {
			st=con.createStatement();
			rs=st.executeQuery("SELECT * FROM islemler");
			while(rs.next()) {
				obj=new PersonelGUI(rs.getString("kullaniciadi"),rs.getString("teslimsaati"),rs.getString("geriteslimsaati"));
				list.add(obj);	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public PersonelGUI() throws SQLException {
		setTitle("Personel Paneli");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 701, 501);
		this.setLocationRelativeTo(null);
		
		islemler=new DefaultTableModel();
		Object[] strislem=new Object[3];
		strislem[0]="Kullan�c� Ad�";
		strislem[1]="�r�n Teslim Saati";
		strislem[2]="�r�n Geri Teslim Saati";
		islemler.setColumnIdentifiers(strislem);
		
		islemVeri=new Object[3];
		for(int i=0; i<get�slemlerList().size(); i++) {
			islemVeri[0]=get�slemlerList().get(i).getKullaniciadi();
			islemVeri[1]=get�slemlerList().get(i).getTeslimsaat();
			islemVeri[2]=get�slemlerList().get(i).getGteslimsaat();
			islemler.addRow(islemVeri);
		}
		
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 205));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 65, 667, 389);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 204, 102));
		tabbedPane.addTab("�r�nlerin Teslim Al�nma ve Teslim Edilme Saatleri", null, panel, null);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 642, 342);
		panel.add(scrollPane);
		
		table = new JTable(islemler);
		scrollPane.setViewportView(table);
		
	}
}
