package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import Model.Admin;
import Model.AdminUrun;

import java.awt.Color;
import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class A_UrunlerGUI extends JFrame {

	private JPanel contentPane;
	private JTable urunlertable;
	private DefaultTableModel urunlerModel=null;
	private Object[] urunlerVeri=null;
	static AdminUrun admin =new AdminUrun();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminUrun a=new AdminUrun();
					A_UrunlerGUI frame = new A_UrunlerGUI(a);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	public A_UrunlerGUI(AdminUrun a) throws SQLException {
		setResizable(false);
		urunlerModel = new DefaultTableModel();
		Object[] strUrunAdi = new Object[2];
		strUrunAdi[0]="�R�N �E��D�";
		strUrunAdi[1]="F�YAT";
		urunlerModel.setColumnIdentifiers(strUrunAdi);
		
		urunlerVeri=new Object[2];
		for(int i=0; i<admin.getUrunlerList().size(); i++) {
			urunlerVeri[0]=admin.getUrunlerList().get(i).getUrun_adi();
			urunlerVeri[1]=admin.getUrunlerList().get(i).getUrun_fiyati();
			urunlerModel.addRow(urunlerVeri);
		}
		
		setTitle("\u00DCr\u00FCn Takip Paneli");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 516, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 205));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		this.setLocationRelativeTo(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(new Color(255, 204, 102));
		tabbedPane.setBounds(10, 130, 484, 423);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 204, 102));
		tabbedPane.addTab("�r�n ve Fiyat Listesi", null, panel, null);
		
		JScrollPane scrollPane = new JScrollPane();
		panel.add(scrollPane);
		
		urunlertable = new JTable(urunlerModel);
		scrollPane.setViewportView(urunlertable);
		
		JButton btnNewButton_1_1 = new JButton("Ana Ekrana Geri D\u00F6n");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Admin admin=new Admin();
				AdminGUI b=new AdminGUI(admin);
				b.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1_1.setToolTipText("");
		btnNewButton_1_1.setFont(new Font("Segoe UI", Font.BOLD, 10));
		btnNewButton_1_1.setBackground(new Color(255, 204, 102));
		btnNewButton_1_1.setBounds(349, 10, 143, 29);
		contentPane.add(btnNewButton_1_1);
	}
}
