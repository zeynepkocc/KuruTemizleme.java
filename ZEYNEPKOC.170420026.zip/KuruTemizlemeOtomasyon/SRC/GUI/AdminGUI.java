package GUI;

import java.awt.EventQueue;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import Model.Admin;
import Model.AdminMus;
import Model.AdminPer;
import Model.AdminUrun;

import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class AdminGUI extends JFrame {
	
	static Admin admin=new Admin();
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminGUI frame = new AdminGUI(admin);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminGUI(Admin admin) {
		setResizable(false);
		setTitle("ADM\u0130N PANEL\u0130");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 205));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		this.setLocationRelativeTo(null);
		
		JLabel logo = new JLabel(new ImageIcon(getClass().getResource("logoadmin.png")));
		logo.setBounds(0, 10, 125, 75);
		contentPane.add(logo);
		
		JLabel lbl1 = new JLabel("Admin: Zeynep Ko\u00E7");
		lbl1.setBounds(10, 95, 115, 16);
		lbl1.setHorizontalAlignment(SwingConstants.CENTER);
		lbl1.setFont(new Font("Segoe UI", Font.BOLD, 12));
		contentPane.add(lbl1);
		
		JButton b_cikis = new JButton("\u00C7IKI\u015E YAP");
		b_cikis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(1);
			}
		});
		b_cikis.setBounds(334, 318, 142, 35);
		b_cikis.setFont(new Font("Segoe UI", Font.BOLD, 12));
		b_cikis.setBackground(new Color(255, 102, 0));
		contentPane.add(b_cikis);
		
		JButton btnIlemdekirnlerinTakibi = new JButton("\u0130\u015Flemdeki \u00DCr\u00FCnlerin Takibi");
		btnIlemdekirnlerinTakibi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminUrun admin=new AdminUrun();
				A_UrunlerGUI u;
				try {
					u = new A_UrunlerGUI(admin);
					u.setVisible(true);
					dispose();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnIlemdekirnlerinTakibi.setForeground(Color.BLACK);
		btnIlemdekirnlerinTakibi.setFont(new Font("Segoe UI", Font.BOLD, 14));
		btnIlemdekirnlerinTakibi.setBackground(new Color(255, 204, 102));
		btnIlemdekirnlerinTakibi.setBounds(80, 193, 320, 35);
		contentPane.add(btnIlemdekirnlerinTakibi);
		
		JButton btnPersonelVeMuhasebe = new JButton("Personel ve Muhasebe Kay\u0131tlar\u0131");
		btnPersonelVeMuhasebe.setForeground(Color.BLACK);
		btnPersonelVeMuhasebe.setFont(new Font("Segoe UI", Font.BOLD, 14));
		btnPersonelVeMuhasebe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminPer a=new AdminPer();
				A_PersonelGUI ps;
				try {
					ps = new A_PersonelGUI(a);
					ps.setVisible(true);
					dispose();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnPersonelVeMuhasebe.setBackground(new Color(255, 204, 102));
		btnPersonelVeMuhasebe.setBounds(80, 238, 320, 35);
		contentPane.add(btnPersonelVeMuhasebe);
		
		JButton btnMteriBilgileriniGrntle = new JButton("M\u00FC\u015Fteri Bilgileri ve \u0130\u015Flemleri");
		btnMteriBilgileriniGrntle.setFont(new Font("Segoe UI", Font.BOLD, 14));
		btnMteriBilgileriniGrntle.setForeground(Color.BLACK);
		btnMteriBilgileriniGrntle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminMus a=new AdminMus();
				A_MusterilerGUI ms;
				try {
					ms = new A_MusterilerGUI(a);
					ms.setVisible(true);
					dispose();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnMteriBilgileriniGrntle.setBackground(new Color(255, 204, 102));
		btnMteriBilgileriniGrntle.setBounds(80, 148, 320, 35);
		contentPane.add(btnMteriBilgileriniGrntle);
	}
}
