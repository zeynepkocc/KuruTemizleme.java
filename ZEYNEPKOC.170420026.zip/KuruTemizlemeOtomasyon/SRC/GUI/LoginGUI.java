package GUI;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import DBHelper.DbConnection;
import Model.Admin;
import Model.Kullanici;
import Model.Musteri;
import Model.MusteriSepeti;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class LoginGUI extends JFrame {

	private JPanel login_pane;
	private JTextField mus_kad;
	private JPasswordField mus_sifre;
	private JTextField per_no;
	private JPasswordField per_sifre;
	private DbConnection conn=new DbConnection();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginGUI frame = new LoginGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginGUI() {
		setResizable(false);
		setTitle("KuruTemizleme Otomasyonu");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		login_pane = new JPanel();
		login_pane.setBackground(new Color(255, 250, 205));
		login_pane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(login_pane);
		login_pane.setLayout(null);
		this.setLocationRelativeTo(null);
		
		JLabel lblNewLabel = new JLabel(new ImageIcon(getClass().getResource("K_logo.png")));
		lblNewLabel.setBounds(10, 10, 114, 81);
		lblNewLabel.setName("logo");
		login_pane.add(lblNewLabel);
		
		JLabel label1 = new JLabel("ZK KURU TEM\u0130ZLEMEYE HO\u015E GELD\u0130N\u0130Z!");
		label1.setBounds(131, 32, 333, 30);
		label1.setForeground(new Color(0, 0, 0));
		label1.setFont(new Font("Segoe UI", Font.BOLD, 16));
		login_pane.add(label1);
		
		JTabbedPane secimpanel = new JTabbedPane(JTabbedPane.TOP);
		secimpanel.setBounds(10, 117, 466, 236);
		secimpanel.setBackground(new Color(255, 250, 205));
		login_pane.add(secimpanel);
		
		JPanel kullanici_p = new JPanel();
		kullanici_p.setBackground(new Color(255, 250, 205));
		secimpanel.addTab("M��teri Giri�i", null, kullanici_p, null);
		kullanici_p.setLayout(null);
		
		JLabel lblKullancAd = new JLabel("KULLANICI ADI: ");
		lblKullancAd.setForeground(Color.BLACK);
		lblKullancAd.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblKullancAd.setBounds(30, 32, 165, 30);
		kullanici_p.add(lblKullancAd);
		
		JLabel lblifre = new JLabel("\u015E\u0130FRE:");
		lblifre.setForeground(Color.BLACK);
		lblifre.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblifre.setBounds(30, 72, 165, 30);
		kullanici_p.add(lblifre);
		
		mus_kad = new JTextField();
		mus_kad.setBounds(205, 41, 195, 19);
		kullanici_p.add(mus_kad);
		mus_kad.setColumns(10);
		
		mus_sifre = new JPasswordField();
		mus_sifre.setBounds(205, 81, 195, 19);
		kullanici_p.add(mus_sifre);
		
		JButton mus_giris = new JButton("G\u0130R\u0130\u015E YAP");
		mus_giris.setBackground(new Color(255, 204, 102));
		mus_giris.setFont(new Font("Segoe UI", Font.BOLD, 14));
		mus_giris.addActionListener(new ActionListener() {
				@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				if(mus_kad.getText().length()==0 || mus_sifre.getText().length()==0) {
					JOptionPane.showMessageDialog(null, "L�tfen alanlar� bo� b�rakmay�n!");
				}else {
					int secim=0;
					try {
						Connection con=conn.connDb();
						Statement st=con.createStatement();
						ResultSet rs=st.executeQuery("SELECT * FROM kullanicilar");
						while(rs.next()) {
							if(mus_kad.getText().equals(rs.getString("KullaniciAdi"))&& mus_sifre.getText().equals(rs.getString("Sifre"))) {
								if(rs.getString("type").equals("M��teri")) {
									Musteri mu=new Musteri();
									mu.setAd(rs.getString("Ad"));
									mu.setSoyad(rs.getString("Soyad"));
									mu.setKullaniciAdi(rs.getString("KullaniciAdi"));
									mu.setSifre(rs.getString("Sifre"));
									mu.setType(rs.getString("type"));
									MusteriSepeti ms=new MusteriSepeti();
									MusteriGUI mg= new MusteriGUI(ms);
									mg.getIsim().setText(mus_kad.getText().toString());
									mg.setVisible(true);
									JOptionPane.showMessageDialog(null, "Temizleme&�t� i�lemi i�in teslim edece�iniz �r�n �e�idini ve �r�n say�s�n� se�iniz!");
									dispose();
									secim=1;
								}
							}
						}
					}catch(SQLException er) {
						er.printStackTrace();
					}
					if (secim==0) {
						JOptionPane.showMessageDialog(null, "Hesap bulunamad�! L�tfen kay�t olunuz!");
					}
				}
			}
		});
		mus_giris.setBounds(235, 145, 165, 41);
		kullanici_p.add(mus_giris);
		
		JButton mus_kaydol = new JButton("KAYDOL");
		mus_kaydol.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GirisGUI grs=new GirisGUI();
				grs.setVisible(true);
				dispose();
			}
		});
		mus_kaydol.setBackground(new Color(255, 204, 102));
		mus_kaydol.setFont(new Font("Segoe UI", Font.BOLD, 14));
		mus_kaydol.setBounds(30, 145, 165, 41);
		kullanici_p.add(mus_kaydol);
		
		JPanel personel_p = new JPanel();
		personel_p.setBackground(new Color(255, 250, 205));
		secimpanel.addTab("Personel Giri�i", null, personel_p, null);
		personel_p.setLayout(null);
		
		JLabel lblPersonelNumaras = new JLabel("PERSONEL ADI:");
		lblPersonelNumaras.setForeground(Color.BLACK);
		lblPersonelNumaras.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblPersonelNumaras.setBounds(30, 32, 174, 30);
		personel_p.add(lblPersonelNumaras);
		
		JLabel lblifre_1 = new JLabel("\u015E\u0130FRE:");
		lblifre_1.setForeground(Color.BLACK);
		lblifre_1.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblifre_1.setBounds(30, 72, 174, 30);
		personel_p.add(lblifre_1);
		
		per_no = new JTextField();
		per_no.setBounds(205, 41, 195, 19);
		personel_p.add(per_no);
		per_no.setColumns(10);
		
		per_sifre = new JPasswordField();
		per_sifre.setBounds(205, 81, 195, 19);
		personel_p.add(per_sifre);
		
		JButton per_giris = new JButton("G\u0130R\u0130\u015E YAP");
		per_giris.setFont(new Font("Segoe UI", Font.BOLD, 14));
		per_giris.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				if(per_no.getText().length()==0 || per_sifre.getText().length()==0) {
					JOptionPane.showMessageDialog(null, "L�tfen alanlar� bo� b�rakmay�n!");
				}else {
					try {
						Connection con=conn.connDb();
						Statement st=con.createStatement();
						ResultSet rs =st.executeQuery("SELECT * FROM kullanicilar");
						while(rs.next()) {
							if(per_no.getText().equals(rs.getString("KullaniciAdi"))&& per_sifre.getText().equals(rs.getString("Sifre"))) {
								if(rs.getString("type").equals("Admin")) {
									Admin a=new Admin();
									a.setAd(rs.getString("Ad"));
									a.setSoyad(rs.getString("Soyad"));
									a.setKullaniciAdi(rs.getString("KullaniciAdi"));
									a.setSifre(rs.getString("Sifre"));
									a.setType(rs.getString("type"));
									AdminGUI agui=new AdminGUI(a);
									agui.setVisible(true);
									dispose();
								}else if(rs.getString("type").equals("Personel")) {
									Kullanici k=new Kullanici();
									k.setAd(rs.getString("Ad"));
									k.setSoyad(rs.getString("Soyad"));
									k.setKullaniciAdi(rs.getString("KullaniciAdi"));
									k.setSifre(rs.getString("Sifre"));
									k.setType(rs.getString("type"));
									PersonelGUI p=new PersonelGUI();
									p.setVisible(true);
									dispose();
								}
							}
						}
					}catch(SQLException er) {
						er.printStackTrace();
					}
				}
			}
		});
		per_giris.setBackground(new Color(255, 204, 102));
		per_giris.setHorizontalTextPosition(SwingConstants.CENTER);
		per_giris.setBounds(30, 145, 370, 41);
		personel_p.add(per_giris);
	}
}
