package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import Model.Musteri;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class GirisGUI extends JFrame {

	private JPanel kayit_pane;
	private JTextField ad_t;
	private JTextField soyad_t;
	private JTextField kad_t;
	private JTextField sfr_t;
	private Musteri mus =new Musteri();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GirisGUI frame = new GirisGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GirisGUI() {
		setResizable(false);
		setTitle("Kaydol");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 500);
		kayit_pane = new JPanel();
		kayit_pane.setBackground(new Color(255, 250, 205));
		kayit_pane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(kayit_pane);
		kayit_pane.setLayout(null);
		this.setLocationRelativeTo(null);
		
		JLabel logo1 = new JLabel(new ImageIcon(getClass().getResource("kayit.png")));
		logo1.setBounds(10, 10, 100, 100);
		kayit_pane.add(logo1);
		
		JLabel logo2 = new JLabel(new ImageIcon(getClass().getResource("kayit2.jpg")));
		logo2.setBounds(476, 10, 100, 100);
		kayit_pane.add(logo2);
		
		JLabel lblNewLabel = new JLabel("ZK KURU TEM\u0130ZLEME");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
		lblNewLabel.setBounds(120, 10, 346, 46);
		kayit_pane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("***KAL\u0130TEN\u0130N TEK ADRES\u0130***");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Segoe UI", Font.BOLD, 18));
		lblNewLabel_1.setBounds(120, 66, 346, 44);
		kayit_pane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("AD:");
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblNewLabel_2.setBounds(85, 160, 100, 13);
		kayit_pane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("SOYAD:");
		lblNewLabel_3.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblNewLabel_3.setBounds(85, 210, 100, 13);
		kayit_pane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("KULLANICI ADI:");
		lblNewLabel_4.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblNewLabel_4.setBounds(85, 260, 118, 13);
		kayit_pane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("\u015E\u0130FRE:");
		lblNewLabel_5.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblNewLabel_5.setBounds(85, 310, 100, 13);
		kayit_pane.add(lblNewLabel_5);
		
		ad_t = new JTextField();
		ad_t.setBounds(262, 160, 204, 19);
		kayit_pane.add(ad_t);
		ad_t.setColumns(10);
		
		soyad_t = new JTextField();
		soyad_t.setColumns(10);
		soyad_t.setBounds(262, 210, 204, 19);
		kayit_pane.add(soyad_t);
		
		kad_t = new JTextField();
		kad_t.setColumns(10);
		kad_t.setBounds(262, 260, 204, 19);
		kayit_pane.add(kad_t);
		
		sfr_t = new JTextField();
		sfr_t.setColumns(10);
		sfr_t.setBounds(262, 310, 204, 19);
		kayit_pane.add(sfr_t);
		
		JButton kydl_b = new JButton("KAYDOL");
		kydl_b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(ad_t.getText().length()==0 || soyad_t.getText().length()==0 || kad_t.getText().length()==0 || sfr_t.getText().length()==0) {
					JOptionPane.showMessageDialog(null, "L�tfen alanlar� bo� b�rakmay�n!");
				}
				else {
					try {
						boolean control =mus.kayit(ad_t.getText(),soyad_t.getText(),kad_t.getText(),sfr_t.getText());
						if(control) {
							JOptionPane.showMessageDialog(null,"Ba�ar�yla kay�t oldunuz!");
							LoginGUI log=new LoginGUI();
							log.setVisible(true);
							dispose();
						}else {
							JOptionPane.showMessageDialog(null, "Kay�t i�lemi ba�ar�s�z!");
						}
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					
				}
			}
		});
		kydl_b.setBackground(new Color(255, 204, 102));
		kydl_b.setFont(new Font("Segoe UI Black", Font.BOLD, 17));
		kydl_b.setBounds(85, 363, 381, 36);
		kayit_pane.add(kydl_b);
	}

}
