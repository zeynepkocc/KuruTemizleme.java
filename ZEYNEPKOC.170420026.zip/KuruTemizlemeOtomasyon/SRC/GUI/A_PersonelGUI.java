package GUI;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import Model.AdminPer;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class A_PersonelGUI extends JFrame {

	private JPanel p4;
	private JTextField pad;
	private JTextField psad;
	private JTextField pno;
	private JTextField psfr;
	private JButton btnNewButton;
	private JTabbedPane tabbedPane;
	private JPanel pnl;
	private JScrollPane scrollPane;
	private JTable personeltab;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JTextField psno;
	private JButton btnPersoneliSil;
	private JLabel lblNewLabel_4;
	private DefaultTableModel personelModel=null;
	private Object[] personelVeri=null;
	private DefaultTableModel islemler=null;
	private Object[] islemVeri=null;
	static AdminPer admin=new AdminPer();
	private JButton btnNewButton_1;
	private JPanel pnl2;
	private JScrollPane scrollPane_1;
	private JTable table;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminPer admin=new AdminPer();
					A_PersonelGUI frame = new A_PersonelGUI(admin);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	public A_PersonelGUI(AdminPer admin) throws SQLException {
		
		personelModel = new DefaultTableModel();
		Object[] strPersonelAdi = new Object[4];
		strPersonelAdi[0]="Ad";
		strPersonelAdi[1]="Soyad";
		strPersonelAdi[2]="Personel No";
		strPersonelAdi[3]="�ifre";
		personelModel.setColumnIdentifiers(strPersonelAdi);
		
		personelVeri=new Object[4];
		for(int i=0; i<admin.getPersonelList().size(); i++) {
			personelVeri[0]=admin.getPersonelList().get(i).getAd();
			personelVeri[1]=admin.getPersonelList().get(i).getSoyad();
			personelVeri[2]=admin.getPersonelList().get(i).getKullaniciAdi();
			personelVeri[3]=admin.getPersonelList().get(i).getSifre();
			personelModel.addRow(personelVeri);
		}
		
		islemler=new DefaultTableModel();
		Object[] strislem=new Object[4];
		strislem[0]="Kullan�c� Ad�";
		strislem[1]="Toplam �cret";
		strislem[2]="�r�n Teslim Saati";
		strislem[3]="�r�n Geri Teslim Saati";
		islemler.setColumnIdentifiers(strislem);
		
		islemVeri=new Object[4];
		for(int i=0; i<admin.get�slemlerList().size(); i++) {
			islemVeri[0]=admin.get�slemlerList().get(i).getKullaniciadi();
			islemVeri[1]=admin.get�slemlerList().get(i).getUcret();
			islemVeri[2]=admin.get�slemlerList().get(i).getTeslimsaat();
			islemVeri[3]=admin.get�slemlerList().get(i).getGteslimsaat();
			islemler.addRow(islemVeri);
		}
		
		setTitle("Personel ve Muhasebe Paneli");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		p4 = new JPanel();
		p4.setBackground(new Color(255, 250, 205));
		p4.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(p4);
		this.setLocationRelativeTo(null);
		p4.setLayout(null);

		
		pad = new JTextField();
		pad.setBounds(578, 308, 184, 19);
		p4.add(pad);
		pad.setColumns(10);
		
		psad = new JTextField();
		psad.setBounds(578, 360, 184, 19);
		p4.add(psad);
		psad.setColumns(10);
		
		pno = new JTextField();
		pno.setBounds(578, 412, 184, 19);
		p4.add(pno);
		pno.setColumns(10);
		
		psfr = new JTextField();
		psfr.setBounds(578, 464, 184, 19);
		p4.add(psfr);
		psfr.setColumns(10);
		
		btnNewButton = new JButton("PERSONEL EKLE");
		btnNewButton.setBounds(578, 505, 184, 37);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(pad.getText().length()==0 || psad.getText().length()==0 || pno.getText().length()==0 || psfr.getText().length()==0) {
					JOptionPane.showMessageDialog(null, "L�tfen alanlar� bo� b�rakmay�n!");
				}else {
					try {
						boolean z=admin.personelEkle(pad.getText(), psad.getText(), pno.getText(), psfr.getText());
						if(z) {
							JOptionPane.showMessageDialog(null, "Personel Ba�ar�yla Eklendi!");
							pad.setText(null);
							psad.setText(null);
							pno.setText(null);
							psfr.setText(null);
							updatePersonelModel();
						}
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		btnNewButton.setBackground(new Color(255, 204, 102));
		btnNewButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
		p4.add(btnNewButton);
		
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 147, 558, 406);
		p4.add(tabbedPane);
		
		pnl = new JPanel();
		pnl.setBackground(new Color(255, 204, 102));
		tabbedPane.addTab("Personel Bilgileri", null, pnl, null);
		pnl.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 534, 359);
		pnl.add(scrollPane);
		
		personeltab = new JTable(personelModel);
		scrollPane.setViewportView(personeltab);
		personeltab.setFont(new Font("Segoe UI", Font.BOLD, 11));
		personeltab.setBackground(new Color(255, 250, 205));
		personeltab.setBounds(10, 10, 534, 359);
		personeltab.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				try {
					psno.setText(personeltab.getValueAt(personeltab.getSelectedRow(), 2).toString());
				}catch(Exception er) {
					er.printStackTrace();
				}
			}
		});
		personeltab.getModel().addTableModelListener(new TableModelListener() {

			@Override
			public void tableChanged(TableModelEvent e) {
				if(e.getType()==TableModelEvent.UPDATE) {
					String k_adi=personeltab.getValueAt(personeltab.getSelectedRow(), 0).toString();
					String k_soyadi=personeltab.getValueAt(personeltab.getSelectedRow(), 1).toString();
					String k_pno=personeltab.getValueAt(personeltab.getSelectedRow(), 2).toString();
					int kont=0;
					String k_sifre=personeltab.getValueAt(personeltab.getSelectedRow(), 3).toString();
					try {
						admin.personelUpdate(k_adi, k_soyadi, k_pno, k_sifre);
						kont=1;
						if(kont==0) {
							JOptionPane.showMessageDialog(null, "Hata!");
						}
					}catch(Exception err) {
						err.printStackTrace();
					}
				}
				
			}
			
		});
		
		pnl2 = new JPanel();
		pnl2.setBackground(new Color(255, 204, 102));
		tabbedPane.addTab("Muhasebe", null, pnl2, null);
		pnl2.setLayout(null);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 10, 533, 359);
		pnl2.add(scrollPane_1);
		
		table = new JTable(islemler);
		scrollPane_1.setViewportView(table);
		
		lblNewLabel = new JLabel("AD:");
		lblNewLabel.setBounds(578, 285, 184, 13);
		lblNewLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
		p4.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("SOYAD:");
		lblNewLabel_1.setBounds(578, 337, 184, 13);
		lblNewLabel_1.setFont(new Font("Segoe UI", Font.BOLD, 12));
		p4.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("PERSONEL NO:");
		lblNewLabel_2.setBounds(578, 389, 184, 13);
		lblNewLabel_2.setFont(new Font("Segoe UI", Font.BOLD, 12));
		p4.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("\u015E\u0130FRE:");
		lblNewLabel_3.setBounds(578, 441, 184, 13);
		lblNewLabel_3.setFont(new Font("Segoe UI", Font.BOLD, 12));
		p4.add(lblNewLabel_3);
		
		psno = new JTextField();
		psno.setBounds(578, 209, 184, 19);
		p4.add(psno);
		psno.setColumns(10);
		
		btnPersoneliSil = new JButton("PERSONEL\u0130 S\u0130L");
		btnPersoneliSil.setBounds(578, 238, 184, 37);
		btnPersoneliSil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(psno.getText().length()==0) {
					JOptionPane.showMessageDialog(null, "L�tfen Silmek �stedi�iniz Personel Numaras�n� Giriniz!");
				}else {
					int cont=0;
					try {
						String personelNo=psno.getText();
						admin.personelSil(personelNo);
						cont=1;
						if(cont==1) {
							psno.setText(null);
							updatePersonelModel();
							JOptionPane.showMessageDialog(null, "Personel Ba�ar�yla Silindi!");
						}
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					
				}
			}
		});
		btnPersoneliSil.setFont(new Font("Segoe UI", Font.BOLD, 13));
		btnPersoneliSil.setBackground(new Color(255, 204, 102));
		p4.add(btnPersoneliSil);
		
		lblNewLabel_4 = new JLabel("PERSONEL NO:");
		lblNewLabel_4.setBounds(578, 186, 184, 13);
		lblNewLabel_4.setFont(new Font("Segoe UI", Font.BOLD, 12));
		p4.add(lblNewLabel_4);
		
		btnNewButton_1 = new JButton("Ana Ekrana Geri D\u00F6n");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminGUI b=new AdminGUI(admin);
				b.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(633, 10, 143, 29);
		btnNewButton_1.setToolTipText("");
		btnNewButton_1.setFont(new Font("Segoe UI", Font.BOLD, 10));
		btnNewButton_1.setBackground(new Color(255, 204, 102));
		p4.add(btnNewButton_1);

	}
	
	public void updatePersonelModel() throws SQLException{
		DefaultTableModel temizle=(DefaultTableModel) personeltab.getModel();
		temizle.setRowCount(0);
		for(int i=0; i<admin.getPersonelList().size(); i++) {
			personelVeri[0]=admin.getPersonelList().get(i).getAd();
			personelVeri[1]=admin.getPersonelList().get(i).getSoyad();
			personelVeri[2]=admin.getPersonelList().get(i).getKullaniciAdi();
			personelVeri[3]=admin.getPersonelList().get(i).getSifre();
			personelModel.addRow(personelVeri);
		}
	}

}
